package com.mcp.chimera.model.exception;

import com.mcp.chimera.common.api.IErrorCode;

/**
 * @author Elliot
 * @description Business status codes and information
 * @date Created in 2024-01-28 09:55 AM
 * @modified_by
 */
public enum BusinessResultCode implements IErrorCode {

    /**
        Auth error codes
     */
    AUTH_NO_USER_OR_EXPIRED("0001", "User not found or password expired"),

    /**
     * Data verification error codes
     */
    DATA_CHECK_EMPTY_USER_ID("1001", "User ID cannot be empty"),

    /**
     * Upload file creation error code
     */
    UPLOAD_FILE_EXCEED_LIMIT("2000", "Upload file size exceeds limit"),
    UPLOAD_CREATE_FILE_ERROR("2001", "Upload create file error");

    private String code;
    private String message;

    private BusinessResultCode(String code, String message) {
        this.code = code;
        this.message = message;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }
}


