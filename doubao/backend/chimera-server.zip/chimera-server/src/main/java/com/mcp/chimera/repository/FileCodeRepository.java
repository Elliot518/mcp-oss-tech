package com.mcp.chimera.repository;

import com.mcp.chimera.entity.FileCode;
import com.mcp.chimera.model.dto.FileCodeDto;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 15:53 2024/2/27
 * @modified by:
 */
@RepositoryRestResource(path = "fileCodeEntities")
public interface FileCodeRepository extends CrudRepository<FileCode, Short> {
  @Query(value = "SELECT fc.id, fc.code, fc.name, fcg.name as category, fc.cat_id as catId, fc.type_id as typeId, ft.typename as typeName," +
          " fc.description, fc.active, fc.created, fc.creator, fc.updated, fc.update_by as updateBy  " +
          "FROM file_code fc, file_category fcg, file_type ft " +
          "WHERE fc.cat_id = fcg.id AND fc.type_id = ft.id order by fc.id desc", nativeQuery = true)
  List<FileCodeDto> listAllFileCodes();
}

