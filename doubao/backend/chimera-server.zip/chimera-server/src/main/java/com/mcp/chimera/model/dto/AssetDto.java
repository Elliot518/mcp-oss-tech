package com.mcp.chimera.model.dto;

import jakarta.persistence.Column;

import java.time.LocalDateTime;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 15:55 2024/6/3
 * @modified by:
 */
public interface AssetDto {
  Long getId();
  String getCode();
  String getName();
  String getDescription();
  Long getOwnerId();
  String getUrl();
  String getLocation();
  Integer getSourceId();
  String getSourceName();
  String getRepoName();
  boolean getIsApi();
  Integer getCategory1Id();
  Integer getCategory2Id();
  Integer getCategory3Id();
  Integer getCategory4Id();
  Integer getCategory5Id();
  Integer getScore();
  String getAssetRank();
  LocalDateTime getCreateDate();
  LocalDateTime getLastUpdate();
}
