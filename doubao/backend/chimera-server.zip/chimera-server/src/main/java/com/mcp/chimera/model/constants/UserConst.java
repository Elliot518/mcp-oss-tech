package com.mcp.chimera.model.constants;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 14:55 2024/5/13
 * @modified by:
 */
public interface UserConst {
  String ROLE = "Role";
}
