package com.mcp.chimera.model.dto;

import lombok.Data;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 20:49 2024/5/13
 * @modified by:
 */
@Data
public class CardDto {
  private Integer id;

  private String title;

  private String content;

  public CardDto(int id, String title, String content) {
    this.id = id;
    this.title = title;
    this.content = content;
  }
}

