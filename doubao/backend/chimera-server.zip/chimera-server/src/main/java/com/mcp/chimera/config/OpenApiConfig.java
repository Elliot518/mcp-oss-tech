package com.mcp.chimera.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 23:38 2024/1/26
 * @modified by:
 */
@Configuration
public class OpenApiConfig {
  @Bean
  public OpenAPI restOpenAPI() {
    return new OpenAPI()
            .info(new Info().title("Chimera REST API").description("Chimera API").version("1.0"))
            .addSecurityItem(new SecurityRequirement().addList("BearerAuth"))
            .components(new Components()
                    .addSecuritySchemes("BearerAuth", new SecurityScheme()
                            .type(SecurityScheme.Type.HTTP)
                            .scheme("bearer")
                            .bearerFormat("JWT")));
  }
}
