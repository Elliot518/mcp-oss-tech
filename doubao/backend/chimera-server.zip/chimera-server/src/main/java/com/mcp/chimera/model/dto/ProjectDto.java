package com.mcp.chimera.model.dto;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 21:17 2024/5/23
 * @modified by:
 */
public interface ProjectDto {
  Short getProjectId();
  Short getRoleId();
  String getRolename();
  String getProjectName();
  String getProjectCaption();
  String getRoutePath();
}
