package com.mcp.chimera.repository;

import java.util.Optional;

import com.mcp.chimera.entity.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(exported = false)
public interface UserRepository extends CrudRepository<User, Long> {
	Optional<User> findByUsername(String username);

	@Query(value = "SELECT * FROM user " +
					"WHERE username = ?1 AND pw_expiry >= NOW()", nativeQuery = true)
	User findNoExpiredUserByName(String username);
}

