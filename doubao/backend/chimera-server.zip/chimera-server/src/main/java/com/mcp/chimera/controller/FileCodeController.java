package com.mcp.chimera.controller;

import com.mcp.chimera.common.api.ResponseResult;
import com.mcp.chimera.model.dto.FileCodeDto;
import com.mcp.chimera.repository.FileCodeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 11:22 2024/2/28
 * @modified by:
 */
@Slf4j
@RestController
@ResponseResult
@RequestMapping("/api/fileCodes")
public class FileCodeController {

  @Autowired
  private FileCodeRepository fileCodeRepository;

  @GetMapping
  public List<FileCodeDto> listAllFileCodes() {
    log.info("Start to list all file codes ...");
    return fileCodeRepository.listAllFileCodes();
  }
}
