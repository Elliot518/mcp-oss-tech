package com.mcp.chimera.controller;

import com.mcp.chimera.common.api.ResponseResult;
import com.mcp.chimera.model.exception.BusinessException;
import com.mcp.chimera.model.exception.BusinessResultCode;
import com.mcp.chimera.model.dto.PersonDto;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 23:16 2024/1/16
 * @modified by:
 */
@RequestMapping("/test")
@RestController
@ResponseResult
public class TestController {
  @GetMapping("/persons")
  public List<PersonDto> listPersons() {
    List<PersonDto> personDtos = new ArrayList<>();
    PersonDto personDto = new PersonDto();

    personDto.setName("Peter");
    personDto.setAge(40);
    personDtos.add(personDto);

    personDto = new PersonDto();
    personDto.setName("Alice");
    personDto.setAge(28);
    personDtos.add(personDto);

    return personDtos;
  }

  @ResponseBody
  @PostMapping(value = "/exception")
  public String testThrowException() {
    throw new BusinessException(BusinessResultCode.UPLOAD_FILE_EXCEED_LIMIT);
  }

  @ResponseBody
  @PostMapping(value = "/valid")
  public String testParamValidation(@Validated @RequestBody PersonDto person) {
    return "Success";
  }
}
