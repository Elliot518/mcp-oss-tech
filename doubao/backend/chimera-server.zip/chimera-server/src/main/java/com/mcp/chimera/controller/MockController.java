package com.mcp.chimera.controller;

import com.mcp.chimera.common.api.ResponseResult;
import com.mcp.chimera.model.dto.CardDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 20:48 2024/5/13
 * @modified by:
 */
@Slf4j
@RestController
@ResponseResult
@RequestMapping("/api/mock")
public class MockController {

  private List<CardDto> mockCards(int num) {
    List<CardDto> cards = new ArrayList<>();

    for (int i = 1; i <= 20; i++) {
      String title = "Card " + i;
      String content = "Content for Card " + i;
      CardDto card = new CardDto(i, title, content);
      cards.add(card);
    }

    return cards;
  }

  @GetMapping("/cards")
  public List<CardDto> getMockCards() {
    return mockCards(20);
  }
}
