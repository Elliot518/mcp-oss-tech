package com.mcp.chimera.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 16:10 2024/2/27
 * @modified by:
 */
@Data
@Entity
public class FileCategory {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Short id;

  private String name;

  private LocalDateTime created;

  private String creator;

  private LocalDateTime revised;

  private String revisedBy;
}

