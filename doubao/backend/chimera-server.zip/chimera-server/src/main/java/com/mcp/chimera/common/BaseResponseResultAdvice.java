package com.mcp.chimera.common;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mcp.chimera.common.api.ResponseResult;
import com.mcp.chimera.common.exception.ApiException;
import com.mcp.chimera.common.api.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.MethodParameter;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.lang.annotation.Annotation;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 11:20 2024/1/29
 * @modified by:
 */
@Slf4j
@RestControllerAdvice
public class BaseResponseResultAdvice {

  private static final Class<? extends Annotation> ANNOTATION_TYPE = ResponseResult.class;

  /** Determine whether a class or method uses @ResponseResult */
  public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
    return AnnotatedElementUtils.hasAnnotation(returnType.getContainingClass(), ANNOTATION_TYPE) || returnType.hasMethodAnnotation(ANNOTATION_TYPE);
  }

  /** This method will be called when a class or method uses @ResponseResult */
  public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType, Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {
    if (body instanceof Result) {
      return body;
    }

    // The String type cannot be packaged directly, so some special processing is required
    if (returnType.getGenericParameterType().equals(String.class)) {
      ObjectMapper objectMapper = new ObjectMapper();
      try {
        // After wrapping the data in BaseResponse, convert it into a json string and respond to the front end
        return objectMapper.writeValueAsString(Result.success(body));
      } catch (JsonProcessingException e) {
        throw new ApiException("Return String type error");
      }
    }

    return Result.success(body);
  }
}

