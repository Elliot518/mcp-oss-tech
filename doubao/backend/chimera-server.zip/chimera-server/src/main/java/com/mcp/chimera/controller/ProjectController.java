package com.mcp.chimera.controller;

import com.mcp.chimera.model.dto.ProjectDto;
import com.mcp.chimera.common.api.ResponseResult;
import com.mcp.chimera.repository.ProjectRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 21:39 2024/5/23
 * @modified by:
 */
@Slf4j
@RestController
@ResponseResult
@RequestMapping("/api/projects")
public class ProjectController {

  @Autowired
  private ProjectRepository projectRepository;

  @GetMapping
  public List<ProjectDto> listProjectsByUserId(@RequestParam(name = "userId") Long userId) {
    return projectRepository.listProjectsByUserId(userId);
  }
}
