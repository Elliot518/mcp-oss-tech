package com.mcp.chimera.common.api;

import lombok.Data;
import lombok.Getter;
import lombok.ToString;

/**
 * @author: Elliot
 * @description: Response return format of controller
 * @date: Created in 10:52 PM 2022/9/21
 * @modified by:
 */
@Data
@Getter
@ToString
public class Result<T> {
    /** Business error code */
    private String code;

    /** Information description */
    private String message;

    /** Returned data */
    private T data;

    private Result(String code, String message) {
        this.code = code;
        this.message = message;
    }

    private Result(ResultCode resultCode, T data) {
        this.code = resultCode.getCode();
        this.message = resultCode.getMessage();
        this.data = data;
    }

    /** Business success returns business code and description information */
    public static Result<Void> success() {
        return new Result<Void>(ResultCode.SUCCESS, null);
    }

    /** Business successfully returns the business code, description and returned parameters. */
    public static <T> Result<T> success(T data) {
        return new Result<T>(ResultCode.SUCCESS, data);
    }

    /** The business successfully returns the business code, description and returned parameters. */
    public static <T> Result<T> success(ResultCode resultCode, T data) {
        if (resultCode == null) {
            return success(data);
        }
        return new Result<T>(resultCode, data);
    }

    /** Business exception returns business code and description letter */
    public static <T> Result<T> failure() {
        return new Result<T>(ResultCode.INTERNAL_SERVER_ERROR, null);
    }

    /** Business exception returns business code, description and returned parameters */
    public static <T> Result<T> failure(ResultCode resultCode) {
        return failure(resultCode, null);
    }

    /** Business exception returns business code, description and returned parameters */
    public static <T> Result<T> failure(ResultCode resultCode, T data) {
        if (resultCode == null) {
            return new Result<T>(ResultCode.INTERNAL_SERVER_ERROR, null);
        }
        return new Result<T>(resultCode, data);
    }

    public static<T> Result<T> failure(String code, String message, T exception) {
        Result<T> result = new Result<>(code, message);

        result.setData(exception);

        return result;
    }

    /**
     * Return result if parameter validation fails
     */
    public static <T> Result<T> validateFailed() {
        return failure(ResultCode.PARAM_INVALID);
    }


    /**
     * Not logged in return results
     */
    public static <T> Result<T> unauthorized() {
        return failure(ResultCode.UNAUTHORIZED);
    }

    /**
     * Unauthorized return of results
     */
    public static <T> Result<T> forbidden(T data) {
        return failure(ResultCode.FORBIDDEN);
    }
}
