package com.mcp.chimera.controller;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 15:47 2024/6/3
 * @modified by:
 */
public class AssetController {
}
