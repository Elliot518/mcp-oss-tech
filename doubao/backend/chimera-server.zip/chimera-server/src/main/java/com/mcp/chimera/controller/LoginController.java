package com.mcp.chimera.controller;

import com.mcp.chimera.entity.User;
import com.mcp.chimera.model.exception.BusinessException;
import com.mcp.chimera.model.exception.BusinessResultCode;
import com.mcp.chimera.model.records.AccountCredentials;
import com.mcp.chimera.model.response.LoginResponse;
import com.mcp.chimera.repository.UserRepository;
import com.mcp.chimera.service.JwtService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Elliot
 * @developer
 * @description Implement the controller class for login
 * @date Created on 2024/03/26 14:40
 * @modified_by
 */
@Tag(name = "1. Login", description = "Use token acquired by login to access the other controllers")
@RestController
public class LoginController {
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    @Autowired
    private UserRepository userRepository;

    public LoginController(JwtService jwtService, AuthenticationManager authenticationManager) {
        this.jwtService = jwtService;
        this.authenticationManager = authenticationManager;
    }

    @PostMapping("/login")
    public ResponseEntity<?> getToken(@RequestBody AccountCredentials credentials) {

        UsernamePasswordAuthenticationToken creds = new UsernamePasswordAuthenticationToken(credentials.username(), credentials.password());
        Authentication auth = authenticationManager.authenticate(creds);

        // Generate token
        String jwts = jwtService.getToken(auth.getName());

        User user = userRepository.findNoExpiredUserByName(credentials.username());
        if (user == null) {
            throw new BusinessException(BusinessResultCode.AUTH_NO_USER_OR_EXPIRED);
        }

        Long userId = user.getId();
        String username = user.getUsername();
        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setUserId(userId);
        loginResponse.setUsername(username);
        loginResponse.setToken(jwts);

        // Build response with the generated token
        return ResponseEntity.ok().header(HttpHeaders.AUTHORIZATION, "Bearer" + jwts)
                .header(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, "Authorization")
                .body(loginResponse);
    }
}

