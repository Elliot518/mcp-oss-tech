package com.mcp.chimera.model.records;

/**
 * @author Elliot
 * @developer
 * @description
 * @date Created on 2024/03/25 21:30
 * @modified_by
 */
public record AccountCredentials(String username, String password) {}

