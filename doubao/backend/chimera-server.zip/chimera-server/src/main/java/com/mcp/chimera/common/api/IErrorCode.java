package com.mcp.chimera.common.api;

/**
 * Encapsulated API error code
 * Created by Elliot on 2022/9/21
 */

public interface IErrorCode {
    String getCode();

    String getMessage();
}


