package com.mcp.chimera.controller;

import com.mcp.chimera.common.api.ResponseResult;
import com.mcp.chimera.model.dto.RobotTaskDto;
import com.mcp.chimera.repository.RobotTaskRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author KG
 * @developer
 * @description
 * @date Created in 2024年03月14日 15:22
 * @modified_by
 */
@Slf4j
@RestController
@ResponseResult
@RequestMapping("/api/robotTasks")
public class RobotTaskController {
    @Autowired
    private RobotTaskRepository robotTaskRepository;

    @GetMapping
    public List<RobotTaskDto> listAllTasks() {
        log.info("Start to list all tasks ...");
        return robotTaskRepository.listAllTasks();
    }
}
