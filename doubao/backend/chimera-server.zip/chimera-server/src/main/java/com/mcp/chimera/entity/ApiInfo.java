package com.mcp.chimera.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 10:45 2024/3/6
 * @modified by:
 */
@Data
@Entity
public class ApiInfo {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  private String name;
}

