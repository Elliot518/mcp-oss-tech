package com.mcp.chimera.model.dto;

import java.time.LocalDateTime;

/**
 * @author KG
 * @developer
 * @description
 * @date Created in 2024年03月14日 15:05
 * @modified_by
 */
public interface RobotTaskDto {
    Long getId();
    String getName();
    Long getUserId();
    Short getStatusId();
    String getStatusName();
    String getVersion();
    LocalDateTime getExpireDate();
    LocalDateTime getCreateDate();
    LocalDateTime getLastUpdate();
}
