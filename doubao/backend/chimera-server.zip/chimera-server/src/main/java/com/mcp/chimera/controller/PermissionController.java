package com.mcp.chimera.controller;

import com.mcp.chimera.common.api.ResponseResult;
import com.mcp.chimera.entity.Permission;
import com.mcp.chimera.repository.PermissionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 15:50 2024/5/19
 * @modified by:
 */
@Slf4j
@RestController
@ResponseResult
@RequestMapping("/api/permissions")
public class PermissionController {

  @Autowired
  private PermissionRepository permissionRepository;

  @GetMapping
  public List<Permission> listPermissionsByRoleAndProject(@RequestParam(name = "roleId") Short roleId, @RequestParam(name = "projectId") Short projectId) {
    return permissionRepository.listPermissionsByCriteria(roleId, projectId);
  }
}
