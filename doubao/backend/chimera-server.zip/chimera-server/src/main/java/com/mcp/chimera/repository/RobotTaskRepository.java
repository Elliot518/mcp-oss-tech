package com.mcp.chimera.repository;

import com.mcp.chimera.entity.RobotTask;
import com.mcp.chimera.model.dto.RobotTaskDto;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 9:39 PM 3/13/24
 * @modified by:
 */
@RepositoryRestResource(path = "robotTaskEntities")
public interface RobotTaskRepository extends CrudRepository<RobotTask, Long> {
    /**
     * list all robot tasks
     * @author KG
     * @date 2024/3/14 15:10
     * @return java.util.List<com.mcp.robot.admin.model.dto.RobotTaskDto>
     */
    @Query(value = """
            SELECT rt.id, rt.name, rt.user_id as userId, rt.status_id as statusId, ts.name as statusName, rt.version, rt.expire_date as expireDate, rt.create_date as createDate, rt.last_update as lastUpdate
            FROM robot_task rt, task_status ts
            WHERE rt.status_id = ts.id 
            """, nativeQuery = true)
    List<RobotTaskDto> listAllTasks();
}
