package com.mcp.chimera.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 15:48 2024/6/3
 * @modified by:
 */
@Data
@Entity
public class AssetInfo {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private String code;

  private String name;

  private String description;

  private Long ownerId;

  private String url;

  private String location;

  private Integer sourceId;

  private String repoName;

  @Column(columnDefinition = "TINYINT(1)")
  private Boolean isApi;

  private Integer category1Id;

  private Integer category2Id;

  private Integer category3Id;

  private Integer category4Id;

  private Integer category5Id;

  private Integer score;

  private String assetRank;

  private LocalDateTime createDate;

  private LocalDateTime lastUpdate;
}
