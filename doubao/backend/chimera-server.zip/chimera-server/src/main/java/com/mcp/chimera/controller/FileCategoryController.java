package com.mcp.chimera.controller;

import com.mcp.chimera.common.api.ResponseResult;
import com.mcp.chimera.entity.FileCategory;
import com.mcp.chimera.repository.FileCategoryRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Elliot
 * @developer
 * @description
 * @date Created on 2024年03月21日 10:58
 * @modified_by
 */
@Slf4j
@RestController
@ResponseResult
@RequestMapping("/api/fileCategories")
public class FileCategoryController {

    @Autowired
    private FileCategoryRepository fileCategoryRepository;

    @GetMapping
    public Iterable<FileCategory> listAllFileCategories() {
        log.info("Start to list all file categories ...");
        return fileCategoryRepository.findAll();
    }
}

