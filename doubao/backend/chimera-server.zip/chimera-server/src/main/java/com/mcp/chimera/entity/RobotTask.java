package com.mcp.chimera.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 8:48 PM 3/9/24
 * @modified by:
 */
@Data
@Entity
public class RobotTask {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private Long userId;

    private Short statusId;

    private LocalDateTime expireDate;

    private LocalDateTime createDate;

    private LocalDateTime lastUpdate;

    private String version;
}
