package com.mcp.chimera.common.api;

import org.springframework.web.bind.annotation.ResponseBody;

import java.lang.annotation.*;

/**
 * @author: Elliot
 * @description: Unified Json Format Annotation
 * @date: Created in 10:33 AM 2022/9/21
 * @modified by:
 */

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD})
@Documented
@ResponseBody
public @interface ResponseResult {
}
