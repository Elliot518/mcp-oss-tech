DROP TABLE IF EXISTS `asset_info`;
CREATE TABLE asset_info (
    id BIGINT auto_increment NOT NULL,
    code varchar(30) NOT NULL,
    name varchar(50) NOT NULL,
    description varchar(255) NULL,
    owner_id BIGINT NULL,
    url varchar(255) NULL,
    location varchar(255) NULL,
    source_id INT NULL,
    repo_name varchar(30) NULL,
    `is_api` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Is it an API',
    category1_id INT NULL,
    category2_id INT NULL,
    category3_id INT NULL,
    category4_id INT NULL,
    category5_id INT NULL,
    score INT NULL,
    asset_rank varchar(5) NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


