
--
-- Table structure for table `doc_code`
--

DROP TABLE IF EXISTS `doc_code`;
CREATE TABLE `doc_code` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `code` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `definition` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Define the use of the code for this type of document.',
  `created` datetime NOT NULL,
  `creator` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `updated` datetime DEFAULT NULL,
  `update_by` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CODE` (`code`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Abbreviations to identify types of documents in file names.';

--
-- Dumping data for table `doc_code`
--

INSERT INTO `doc_code` VALUES (1,'PI','Proforma Invoice','Incoming or outgoing.','2024-02-20 17:59:48','Arne Wink',NULL,NULL),(2,'CR','Credit note / Credit advice','Incoming or outgoing.','2024-02-20 18:01:37','Arne Wink',NULL,NULL),(3,'CN','Contract','Incoming or outgoing.','2024-02-20 18:01:37','Arne Wink',NULL,NULL),(4,'OF','Offer','Incoming or outgoing.','2024-02-20 18:01:37','Arne Wink',NULL,NULL),(5,'OC','Order Confirmation','Incoming or outgoing.','2024-02-20 18:01:37','Arne Wink',NULL,NULL),(6,'OR','Order','Incoming or outgoing.','2024-02-20 18:01:37','Arne Wink',NULL,NULL),(7,'FX','Telefax','Incoming or outgoing.','2024-02-20 18:01:37','Arne Wink',NULL,NULL);

--
-- Table structure for table `file_category`
--

DROP TABLE IF EXISTS `file_category`;
CREATE TABLE `file_category` (
  `id` smallint NOT NULL AUTO_INCREMENT COMMENT 'FK in file_codes',
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `creator` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `revised` datetime DEFAULT NULL,
  `revised_by` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CATEGORY` (`name`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Categories of file codes. Foreign Key in table file_codes.';

--
-- Dumping data for table `file_category`
--

INSERT INTO `file_category` VALUES (1,'Individual','2024-02-08 15:03:31','Arne Wink',NULL,NULL),(2,'Company','2024-02-08 15:03:31','Arne Wink',NULL,NULL),(3,'Government','2024-02-08 15:03:31','Arne Wink',NULL,NULL),(4,'Subject','2024-02-08 15:03:31','Arne Wink',NULL,NULL);

--
-- Table structure for table `file_code`
--

DROP TABLE IF EXISTS `file_code`;
CREATE TABLE `file_code` (
  `id` smallint NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `code` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'File code',
  `name` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Search criterium.',
  `cat_id` smallint NOT NULL COMMENT 'FK for file_category',
  `type_id` smallint NOT NULL COMMENT 'FK of file_type',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1' COMMENT 'Archived if not active.',
  `created` datetime NOT NULL,
  `creator` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `updated` datetime DEFAULT NULL,
  `update_by` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI` (`code`),
  KEY `file_codes_file_categories_fk` (`cat_id`),
  KEY `file_codes_file_types_fk` (`type_id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Filing codes uniquely identify a party uniquely.';

--
-- Dumping data for table `file_code`
--

INSERT INTO `file_code` VALUES (1,'AMP','Agent: Milan',1,3,'Milan Popovic Remark',0,'2023-04-25 00:00:00','Arne Wink','2024-05-10 21:39:03','Admin'),(2,'AET','Agencia Tributaria',3,5,'Tax administration',1,'2023-11-25 00:00:00','Arne Wink',NULL,NULL),(3,'AHO','Ahorra Deal SL',2,2,'Car rental, Mijas',1,'2023-11-26 00:00:00','Arne Wink',NULL,NULL),(4,'AIC','Adam Idriss Chughtai',1,4,'Telemarketer: Terminated Nov 2023',1,'2023-06-25 00:00:00','Arne Wink','2024-05-10 21:00:40','Admin'),(5,'ALC','Agent: Liam',1,3,'Liam Padraig O\'Connor',1,'2023-06-25 00:00:00','Arne Wink',NULL,NULL),(6,'APS','A Place In The Sun',2,2,'Real estate portal',1,'2023-11-25 00:00:00','Arne Wink',NULL,NULL),(7,'AQS','Aquaservice SL',2,2,'Water & coffee',1,'2024-03-08 22:56:05','Arne Wink',NULL,''),(9,'ART','Arturo Carilla',1,2,'Photographer',1,'2023-11-26 00:00:00','Arne Wink',NULL,NULL),(10,'AWK','Arne Wink',1,1,'Self',0,'2024-04-10 04:35:18','Admin','2024-05-08 22:09:58','Admin'),(11,'EGU','Elliot Gu',2,3,'Principal Architect',0,'2024-04-16 19:48:30','string','2024-05-08 22:08:04','Admin'),(12,'GGA','Agriculture',3,3,'All OK or NOT',1,'2024-04-17 03:22:39','Admin','2024-04-24 05:06:53','Admin');

--
-- Table structure for table `file_type`
--

DROP TABLE IF EXISTS `file_type`;
CREATE TABLE `file_type` (
  `id` smallint NOT NULL AUTO_INCREMENT COMMENT 'FK in file_codes',
  `typename` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `creator` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `revised` datetime DEFAULT NULL,
  `revised_by` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CATEGORY` (`typename`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Categories of file codes. Foreign Key in table file_codes.';

--
-- Dumping data for table `file_type`
--

INSERT INTO `file_type` VALUES (1,'Customer/Client','2024-02-08 15:34:18','Arne Wink',NULL,NULL),(2,'Supplier','2024-02-08 15:34:18','Arne Wink',NULL,NULL),(3,'Associate','2024-02-08 15:34:18','Arne Wink',NULL,NULL),(4,'Employee','2024-02-08 15:34:18','Arne Wink',NULL,NULL),(5,'Other','2024-02-08 15:34:18','Arne Wink',NULL,NULL);

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission` (
  `id` smallint NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `name` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `caption` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `creator` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `revised` datetime DEFAULT NULL,
  `revised_by` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PERM_NAME` (`name`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='permission table';

--
-- Dumping data for table `permission`
--

INSERT INTO `permission` VALUES (1,'add','Add','2024-05-22 22:55:59','Elliot',NULL,NULL),(2,'edit','Edit','2024-05-22 22:55:59','Elliot',NULL,NULL),(3,'delete','Delete','2024-05-22 22:55:59','Elliot',NULL,NULL),(4,'status','Status','2024-05-22 22:55:59','Elliot',NULL,NULL);

--
-- Table structure for table `permission_config`
--

DROP TABLE IF EXISTS `permission_config`;
CREATE TABLE `permission_config` (
  `id` smallint NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `project_id` smallint NOT NULL,
  `role_id` smallint NOT NULL,
  `perm_id` smallint NOT NULL,
  `created` datetime NOT NULL,
  `creator` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `revised` datetime DEFAULT NULL,
  `revised_by` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PERMISSION_CONFIG_UN` (`project_id`,`role_id`,`perm_id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='permission config';

--
-- Dumping data for table `permission_config`
--

INSERT INTO `permission_config` VALUES (1,1,2,1,'2024-05-23 09:40:26','Elliot',NULL,NULL),(2,1,2,2,'2024-05-23 09:40:26','Elliot',NULL,NULL),(3,1,2,4,'2024-05-23 09:40:26','Elliot',NULL,NULL),(4,1,3,1,'2024-05-23 09:40:26','Elliot',NULL,NULL),(5,1,3,2,'2024-05-23 09:40:26','Elliot',NULL,NULL),(6,1,3,3,'2024-05-23 09:40:26','Elliot',NULL,NULL),(7,1,3,4,'2024-05-23 09:40:26','Elliot',NULL,NULL);

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
CREATE TABLE `project` (
  `id` smallint NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `caption` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `route_path` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  `creator` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `revised` datetime DEFAULT NULL,
  `revised_by` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PROJECT_NAME` (`name`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='project table';

--
-- Dumping data for table `project`
--

INSERT INTO `project` VALUES (1,'file_code','File Code','/fileCode','2024-05-22 22:50:39','Elliot',NULL,NULL),(2,'doc_code','Doc Code','/docCode','2024-05-22 22:50:39','Elliot',NULL,NULL);

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` smallint NOT NULL AUTO_INCREMENT COMMENT 'FK of role_id in user',
  `rolename` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `creator` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `revised` datetime DEFAULT NULL,
  `revised_by` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ROLE_NAME` (`rolename`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Roles of user. Foreign Key in table user.';

--
-- Dumping data for table `role`
--

INSERT INTO `role` VALUES (1,'User','2024-05-16 11:02:10','Elliot',NULL,NULL),(2,'Manager','2024-05-16 11:02:10','Elliot',NULL,NULL),(3,'Owner','2024-05-16 11:02:10','Elliot',NULL,NULL),(4,'Administrator','2024-05-16 11:02:10','Elliot',NULL,NULL);

--
-- Table structure for table `role_config`
--

DROP TABLE IF EXISTS `role_config`;
CREATE TABLE `role_config` (
  `id` smallint NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `user_id` bigint NOT NULL,
  `project_id` smallint NOT NULL,
  `role_id` smallint NOT NULL,
  `created` datetime NOT NULL,
  `creator` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `revised` datetime DEFAULT NULL,
  `revised_by` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ROLE_CONFIG_UN` (`user_id`,`project_id`,`role_id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='role config';

--
-- Dumping data for table `role_config`
--

INSERT INTO `role_config` VALUES (1,1,1,1,'2024-05-22 23:04:03','Elliot',NULL,NULL),(2,2,1,2,'2024-05-22 23:04:03','Elliot',NULL,NULL),(3,3,1,3,'2024-05-22 23:04:03','Elliot',NULL,NULL),(4,4,1,4,'2024-05-22 23:04:03','Elliot',NULL,NULL),(5,1,2,1,'2024-05-23 21:25:38','Elliot',NULL,NULL),(6,2,2,2,'2024-05-23 21:25:38','Elliot',NULL,NULL),(7,3,2,3,'2024-05-23 21:25:38','Elliot',NULL,NULL),(8,4,2,4,'2024-05-23 21:25:38','Elliot',NULL,NULL);

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `pw_expiry` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_pw_expiry_UN` (`username`,`pw_expiry`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` VALUES (1,'peter','$2a$10$vA0f7jfnya2aozaWTUNoRe0BGilPPI/YlJvpO4YhQZFn0IkZe2.2m','2024-05-22 11:54:44'),(2,'milan','$2a$10$vA0f7jfnya2aozaWTUNoRe0BGilPPI/YlJvpO4YhQZFn0IkZe2.2m','2024-06-18 11:54:44'),(3,'awink','$2a$10$vA0f7jfnya2aozaWTUNoRe0BGilPPI/YlJvpO4YhQZFn0IkZe2.2m','2024-06-18 11:54:44'),(4,'egu','$2a$10$vA0f7jfnya2aozaWTUNoRe0BGilPPI/YlJvpO4YhQZFn0IkZe2.2m','2024-06-18 11:54:44');

