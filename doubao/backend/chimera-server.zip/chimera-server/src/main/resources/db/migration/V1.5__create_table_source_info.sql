DROP TABLE IF EXISTS `source_info`;
CREATE TABLE source_info (
    id INT auto_increment NOT NULL,
    name varchar(30) NOT NULL,
    home_page varchar(255) NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


insert into source_info(name, home_page, create_date)
values('Gitee', 'https://gitee.com', NOW());

insert into source_info(name, home_page, create_date)
values('Github', 'https://github.com', NOW());

insert into source_info(name, home_page, create_date)
values('Bitbucket', 'https://bitbucket.org', NOW());

insert into source_info(name, home_page, create_date)
values('AliDrive', 'https://www.aliyundrive.com', NOW());


