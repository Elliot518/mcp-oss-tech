DROP TABLE IF EXISTS `endpoint_param`;
CREATE TABLE endpoint_param (
    id BIGINT auto_increment NOT NULL,
    p_key varchar(50) NOT NULL,
    p_value varchar(255) NOT NULL,
    description varchar(255) NOT NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `endpoint_authorization`;
CREATE TABLE endpoint_authorization (
    id INT auto_increment NOT NULL,
    auth_type_id INT NULL,
    bearer_token varchar(255) NULL,
    username varchar(50) NULL,
    password varchar(255) NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `endpoint_header`;
CREATE TABLE endpoint_header (
    id INT auto_increment NOT NULL,
    h_key varchar(50) NOT NULL,
    h_value varchar(255) NOT NULL,
    description varchar(255) NOT NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `endpoint_body`;
CREATE TABLE endpoint_body (
    id INT auto_increment NOT NULL,
    content_type_id INT NULL,
    body_value TEXT NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `content_type_info`;
CREATE TABLE content_type_info (
    id INT auto_increment NOT NULL,
    name varchar(20) NOT NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

insert into content_type_info(name, create_date)
values('JSON', NOW());

insert into content_type_info(name, create_date)
values('HTML', NOW());

insert into content_type_info(name, create_date)
values('XML', NOW());

insert into content_type_info(name, create_date)
values('JavaScript', NOW());

insert into content_type_info(name, create_date)
values('Text', NOW());






















