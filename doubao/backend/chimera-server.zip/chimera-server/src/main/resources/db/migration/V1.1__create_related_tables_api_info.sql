--
-- Table structure for table `api_info`
--

DROP TABLE IF EXISTS `api_info`;
CREATE TABLE `api_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `asset_id` BIGINT DEFAULT NULL,
  `version_id` int DEFAULT NULL,
  `status_id` smallint DEFAULT NULL,
  `owner_id` bigint DEFAULT NULL,
  category5_id INT NULL,
  `create_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `api_status`
--

DROP TABLE IF EXISTS `api_status`;
CREATE TABLE `api_status` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

insert into api_status(name, create_date)
values('RELEASED', NOW());

insert into api_status(name, create_date)
values('IN DESIGN', NOW());

insert into api_status(name, create_date)
values('IN DEV', NOW());


insert into api_status(name, create_date)
values('DISCARDED', NOW());

--
-- Table structure for table `env_info`
--

DROP TABLE IF EXISTS `env_info`;
CREATE TABLE `env_info` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `create_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

insert into env_info(name, create_date)
values('DEV', NOW());

insert into env_info(name, create_date)
values('TEST', NOW());


insert into env_info(name, create_date)
values('PROD', NOW());

DROP TABLE IF EXISTS `server_info`;
CREATE TABLE server_info (
    id INT auto_increment NOT NULL,
    name varchar(30) NOT NULL,
    home_page varchar(255) NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

insert into server_info(name, home_page, create_date)
values('Aliyun', 'https://www.aliyun.com', NOW());

insert into server_info(name, home_page, create_date)
values('AWS', 'https://aws.amazon.com', NOW());

insert into server_info(name, home_page, create_date)
values('TencentCloud', 'https://cloud.tencent.com', NOW());

insert into server_info(name, home_page, create_date)
values('UCloud', 'https://www.ucloud.cn', NOW());

DROP TABLE IF EXISTS `api_in_run`;
CREATE TABLE `api_in_run` (
  `id` int NOT NULL AUTO_INCREMENT,
  `api_id` INT NOT NULL,
  `version_id` int DEFAULT NULL,
  `env_id` smallint DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
