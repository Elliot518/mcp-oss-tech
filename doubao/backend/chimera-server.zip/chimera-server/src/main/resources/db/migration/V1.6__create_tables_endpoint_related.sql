DROP TABLE IF EXISTS `arch_style`;
CREATE TABLE arch_style (
    id INT auto_increment NOT NULL,
    name varchar(20) NOT NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

insert into arch_style(name, create_date)
values('REST', NOW());
insert into arch_style(name, create_date)
values('RPC', NOW());

DROP TABLE IF EXISTS `http_method_info`;
CREATE TABLE http_method_info (
    id INT auto_increment NOT NULL,
    name varchar(20) NOT NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

insert into http_method_info(name, create_date)
values('GET', NOW());
insert into http_method_info(name, create_date)
values('POST', NOW());
insert into http_method_info(name, create_date)
values('PUT', NOW());
insert into http_method_info(name, create_date)
values('DELETE', NOW());
insert into http_method_info(name, create_date)
values('PATCH', NOW());

DROP TABLE IF EXISTS `endpoint_info`;
CREATE TABLE endpoint_info (
    id BIGINT auto_increment NOT NULL,
    name varchar(30) NOT NULL,
    asset_id BIGINT NULL,
    relative_url varchar(255) NULL,
    arch_style_id INT NULL,
    http_method_id INT NULL,
    response_example TEXT NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

