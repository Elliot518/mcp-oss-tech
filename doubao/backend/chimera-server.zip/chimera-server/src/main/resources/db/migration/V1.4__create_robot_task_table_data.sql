DROP TABLE IF EXISTS `robot_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `robot_task` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` bigint NOT NULL,
  `status_id` smallint NOT NULL,
  `expire_date` datetime DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


--
-- Table structure for table `task_status`
--

DROP TABLE IF EXISTS `task_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_status` (
    `id` smallint NOT NULL AUTO_INCREMENT,
    `name` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
    `description` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
    `create_date` datetime DEFAULT NULL,
    `last_update` datetime DEFAULT NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


ALTER TABLE robot_task ADD version varchar(20) NULL;


INSERT INTO task_status
(name, description, create_date)
VALUES('Running', 'Task is running', NOW());

INSERT INTO task_status
(name, description, create_date)
VALUES('Stopped', 'Task stopped manually', NOW());

INSERT INTO task_status
(name, description, create_date)
VALUES('Aborted', 'Task aborted by exception', NOW());












