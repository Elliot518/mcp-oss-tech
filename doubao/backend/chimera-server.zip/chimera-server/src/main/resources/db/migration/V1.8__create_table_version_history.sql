DROP TABLE IF EXISTS `asset_version_history`;
CREATE TABLE asset_version_history (
    id BIGINT auto_increment NOT NULL,
    `name` varchar(50) NOT NULL,
    asset_id BIGINT NOT NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `api_version_history`;
CREATE TABLE api_version_history (
    id BIGINT auto_increment NOT NULL,
    `name` varchar(50) NOT NULL,
    api_id INT NOT NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
