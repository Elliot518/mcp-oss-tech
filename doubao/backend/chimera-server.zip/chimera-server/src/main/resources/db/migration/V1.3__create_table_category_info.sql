DROP TABLE IF EXISTS `category_info`;
CREATE TABLE category_info (
    id INT auto_increment NOT NULL,
    name varchar(30) NOT NULL,
    description varchar(255) NULL,
    cat_level INT NULL,
    create_date DATETIME NULL,
    last_update DATETIME NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Level 1
insert into category_info(name, cat_level, create_date)
values('Code', 1, NOW());
insert into category_info(name, cat_level, create_date)
values('Book', 1, NOW());
insert into category_info(name, cat_level, create_date)
values('Server', 1, NOW());
insert into category_info(name, cat_level, create_date)
values('Hardware', 1, NOW());

-- Level 2
insert into category_info(name, cat_level, create_date)
values('BackEnd', 2, NOW());
insert into category_info(name, cat_level, create_date)
values('FrontEnd', 2, NOW());
insert into category_info(name, cat_level, create_date)
values('Mobile', 2, NOW());
insert into category_info(name, cat_level, create_date)
values('DataScience', 1, NOW());
insert into category_info(name, cat_level, create_date)
values('AI', 1, NOW());


-- Level 3
insert into category_info(name, cat_level, create_date)
values('Java', 3, NOW());

insert into category_info(name, cat_level, create_date)
values('Python', 3, NOW());

insert into category_info(name, cat_level, create_date)
values('JavaScript', 3, NOW());
insert into category_info(name, cat_level, create_date)
values('TypeScript', 3, NOW());



insert into category_info(name, cat_level, create_date)
values('C++', 3, NOW());
insert into category_info(name, cat_level, create_date)
values('Go', 3, NOW());


-- Level 4
insert into category_info(name, cat_level, create_date)
values('SpringBoot3', 4, NOW());

insert into category_info(name, cat_level, create_date)
values('SpringBoot2', 4, NOW());

insert into category_info(name, cat_level, create_date)
values('Vue3', 4, NOW());

insert into category_info(name, cat_level, create_date)
values('Vue2', 4, NOW());

insert into category_info(name, cat_level, create_date)
values('React', 4, NOW());


-- Level 5
insert into category_info(name, cat_level, create_date)
values('e-Commerce', 5, NOW());

insert into category_info(name, cat_level, create_date)
values('IMS', 5, NOW());

insert into category_info(name, cat_level, create_date)
values('Platform', 5, NOW());

insert into category_info(name, cat_level, create_date)
values('SupplyChain', 5, NOW());






